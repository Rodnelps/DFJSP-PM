clc;
clear all;

documentPath = 'DFJSP_instances/';  
fileList = dir(fullfile(documentPath, '*.txt')); 
for i=1:length(fileList)
    fileNames{i} = fileList(i).name; 
    readPath{i} = fullfile(documentPath, fileNames{i});
    [~,res_fileName,~] = fileparts(fileNames{i});
    resultFile{i} = [res_fileName, '_result'];
end

while true
    input_vectors = input('请输入要运行的测试算例编号范围(如[1,20]): \n');
    if input_vectors(2) > length(fileList)
        disp('输入编号超过设定算例数上限，请重新输入！')
    else
        break
    end
end
exper_num = input('请输入每组测试算例需要进行的实验次数: \n');


global factory_num  job_num  mch_num  operNum  avi_mchNum  avi_mchList...
        mch_time  total_operNum  popSize  deterRate  CM_threshold...
        CM_time  unit_M_cost  unit_P_ec  unit_I_ec  unit_M_ec...
        crossover_rate  mutation_rate  obj_num...
        AP AM AF AN


popSize = 100; 
fit_eval_num = 70000; 
greedy_factor = 0.6;
gamma = 0.9;
alpha = 0.2;

deterRate = 0.1; 
CM_threshold = 60;
CM_time = 5;
unit_M_cost = 10; 
unit_P_ec = 8; 
unit_I_ec = 1; 
unit_M_ec = 2;
obj_num = 3;
crossover_rate = 1;
mutation_rate = 0.25;
%% 算法整体框架

for fileIndex=input_vectors(1):input_vectors(2) 
    [factory_num,job_num,mch_num,operNum,avi_mchNum,avi_mchList,...
        mch_time,total_operNum] = read_instance(readPath{fileIndex});
    
    folderName = ['DFJSP_results/' resultFile{fileIndex}];
    
    if ~exist(folderName,"dir")
       mkdir(folderName);
    end

    folderName_ = ['LBPEA_time_results/' resultFile{fileIndex}];
    if ~exist(folderName_,"dir")
       mkdir(folderName_);
    end

    fprintf('%s %s\r\n','当前求解算例为：',readPath{fileIndex});

    for round=1:exper_num

        tic; %计时

        init_pop = cell(popSize,4);
        NFEs=0;

        for i=1:popSize
            [OS_code,MS_code,FS_code] = encode();
            [OS_code,MS_code,FS_code] = PM_encode(OS_code,MS_code,FS_code); 
            init_pop{i,1} = OS_code;init_pop{i,2} = MS_code;init_pop{i,3} = FS_code;
            [newOS_code,obj1,obj2,obj3,~,~,~] = new_decode(OS_code,MS_code,FS_code); 
            init_pop{i,1} = newOS_code;
            init_pop{i,4} = [obj1,obj2,obj3]; 
            NFEs=NFEs+1;
        end
       
        AP={};AM={};AN={};AF={};
       
        % 创建一个初始散点图
%         figure;
%         h = scatter3([], [], [], 'filled', 'MarkerFaceColor', 'k', 'MarkerFaceAlpha', 0.7); % 创建一个空的散点图对象
%         xlabel('Maintenance cost');
%         ylabel('Makespan');
%         zlabel('Energy consumption');

        % 创建Q表
        Qtable=zeros(6,5); 

        while NFEs<fit_eval_num 

            disp(['适值评估次数为：', num2str(NFEs)]);
                       
            fit = zeros(popSize,obj_num);
            for i=1:popSize
                fit(i,:) = init_pop{i,4};
            end

            MatingPool = TSelection(fit); 

            offspring = cell(popSize,4); curr_pos = 0;
            for i = 1:popSize
                r=ceil(rand*popSize);
                while MatingPool(i)==MatingPool(r)
                    r=ceil(rand*popSize);
                end
                i1 = MatingPool(i); i2 = MatingPool(r);
                OS_1 = init_pop{i1,1}; MS_1 = init_pop{i1,2}; FS_1 = init_pop{i1,3};
                OS_2 = init_pop{i2,1}; MS_2 = init_pop{i2,2}; FS_2 = init_pop{i2,3};
                if rand <= crossover_rate
                    [OS_1,MS_1,FS_1,OS_2,MS_2,FS_2] = crossover(OS_1,MS_1,FS_1,OS_2,MS_2,FS_2);
                end
                if rand <= mutation_rate
                  [OS_1,MS_1,FS_1] = mutation(OS_1,MS_1,FS_1);
                  [OS_2,MS_2,FS_2] = mutation(OS_2,MS_2,FS_2);
                end
                [f1(1,1),f1(1,2),f1(1,3),~,~,~] = semiAS_decode(OS_1,MS_1,FS_1);
                [f2(1,1),f2(1,2),f2(1,3),~,~,~] = semiAS_decode(OS_2,MS_2,FS_2);
                NFEs=NFEs+2;
                
                offspring{curr_pos+1,1} = OS_1; offspring{curr_pos+2,1} = OS_2; 
                offspring{curr_pos+1,2} = MS_1; offspring{curr_pos+2,2} = MS_2; 
                offspring{curr_pos+1,3} = FS_1; offspring{curr_pos+2,3} = FS_2; 
                offspring{curr_pos+1,4} = f1;   offspring{curr_pos+2,4} = f2;
                curr_pos=curr_pos+2;
            end

            init_pop = [init_pop; offspring];
            init_pop = DeleteRpeatQF(init_pop);
            
            pop_len = size(init_pop,1);
            init_pop = init_pop(randperm(pop_len),:); 
            subpop1 = init_pop(1:floor(pop_len/2),:);
            subpop2 = init_pop(floor(pop_len/2)+1:end,:);

            subpop1_num = floor(popSize/2);
            TopPSRank = FastNDS(subpop1,subpop1_num); 
            subpop1 = subpop1(TopPSRank,:);
            subpop2_num = popSize - subpop1_num;
            TopPSRank = pop2_selection(subpop2,subpop2_num);
            subpop2 = subpop2(TopPSRank,:);

            init_pop = [subpop1; subpop2];

            last_AF = AF;

            for j=1:popSize
                [newOS_code,~,~,~,~,~,~] = AS_decode(init_pop{j,1},init_pop{j,2},init_pop{j,3});
                [newOS_code,obj1,obj2,obj3,actionList,~,~] = fullAS_decode(newOS_code,init_pop{j,2},init_pop{j,3}); NFEs=NFEs+1;
                newfit = [obj1,obj2,obj3]; fitness = init_pop{j,4};
                if NDS(newfit,fitness)==1 
                    init_pop{j,1} = newOS_code;
                    init_pop{j,4} = newfit;
                    AP=[AP;init_pop(j,1)];
                    AM=[AM;init_pop(j,2)];
                    AN=[AN;init_pop(j,3)];
                    AF=[AF;init_pop(j,4)];                        
                elseif NDS(newfit,fitness)==0 
                    AP=[AP;{newOS_code}];
                    AM=[AM;init_pop(j,2)];
                    AN=[AN;init_pop(j,3)];
                    AF=[AF;{newfit}];                            
                end
            end

            L=size(init_pop,1);
            obj=zeros(L,obj_num);
            for l=1:L
                obj(l,:) = init_pop{l,4};
            end
            [PF,~]=pareto1(obj);
            AP=[AP;init_pop(PF,1)];AM=[AM;init_pop(PF,2)];AN=[AN;init_pop(PF,3)];AF=[AF;init_pop(PF,4)]; 
            L=size(AF,1);
            obj=zeros(L,obj_num);
            for l=1:L
                obj(l,:) = AF{l};
            end
            [PF,~]=pareto1(obj);
            AP=AP(PF,:);AM=AM(PF,:);AN=AN(PF,:);AF=AF(PF,:);
            DeleteRpeat();

            L=size(AF,1);
            newobj=[];
            for i=1:L
                newobj(i,:)=AF{i};   
            end

            %% 局部搜索
            L = size(last_AF,1);
            last_NDS_num = sum(ismember(1:L,PF));
            if L == 0
                PR = 0;
            else
                PR = last_NDS_num / L;
            end
%             disp(['当前非支配解集中上一代非支配解的占比：', num2str(PR)]);
           
            L=size(AF,1);
            obj=zeros(L,obj_num);
            for l=1:L
                obj(l,:) = AF{l};
            end


            if PR > 0.9 

                L = size(AF,1);
                objList = zeros(L,obj_num);
                for l = 1:L
                    objList(l,:) = AF{l};
                end

                L=size(AF,1);
                for i = 1:L
                    fitness = AF{i};
                    OS = AP{i}; MS = AM{i}; FS = AN{i}; 

                    [curr_state,~,~] = get_state(fitness,objList);

                    if rand > greedy_factor || all(Qtable(curr_state,:)==0)
                        action = ceil(rand * size(Qtable,2)); 
                    else
                        [~,action] = max(Qtable(curr_state,:));
                    end

                    k = action;
                    switch k
                        case{1}
                            [newOS,newMS,newFS] = localSearch_1(OS,MS,FS);
                            
                        case{2}
                            [newOS,newMS,newFS] = localSearch_2(OS,MS,FS);
                            
                        case{3}
                            [newOS,newMS,newFS] = localSearch_3(OS,MS,FS);

                        case{4}
                            [newOS,newMS,newFS] = localSearch_4(OS,MS,FS);

                        case{5}
                            [newOS,newMS,newFS] = localSearch_5(OS,MS,FS);
                    end
                    
                    [F1(1,1),F1(1,2),F1(1,3),actionList,~,~] = semiAS_decode(newOS,newMS,newFS); NFEs=NFEs+1;
 
                    %正则化
                    [~,norm_old_solution,~] = get_state(fitness,objList);

                    if NDS(F1,fitness) == 1
                        AP{i}=newOS;
                        AM{i}=newMS;
                        AN{i}=newFS;
                        AF{i}=F1;
                        
                    elseif NDS(F1,fitness) == 0
                        AP=[AP;{newOS}];
                        AM=[AM;{newMS}];
                        AN=[AN;{newFS}];
                        AF=[AF;{F1}];
                    end


                    if isequal(newOS,OS) && isequal(newMS,MS) && isequal(newFS,FS)  %避免JSP问题LS2策略失效导致学习效果差
                        reward = -1;
                        next_state = curr_state;
                    else
                        objList(i,:) = AF{i};
                        [next_state,norm_new_solution,sortIndex] = get_state(AF{i},objList);
                        improveList = max(norm_new_solution - norm_old_solution, [0,0,0]);
                        positive_indices = find(improveList~=0);
                        if isempty(positive_indices)
                            reward = -1;
                        else
                            reward = 0;
                            if ismember(sortIndex(1),positive_indices)
                                reward = reward + 0.3 * improveList(sortIndex(1));
                            end
                            if ismember(sortIndex(2),positive_indices)
                                reward = reward + 0.2 * improveList(sortIndex(2));
                            end
                            if ismember(sortIndex(3),positive_indices)
                                reward = reward + 0.1 * improveList(sortIndex(3));
                            end
                        end
                    end

                    maxreward = max(Qtable(next_state,:));
                    Qtarget = reward + gamma * maxreward;
                    Qtable(curr_state,action) = Qtable(curr_state,action) + ...
                                                alpha * (Qtarget- Qtable(curr_state,action));

                    %调整PM
                    newOS = adjustPM(newOS,actionList); 
                    [F1(1,1),F1(1,2),F1(1,3),~,~,~] = semiAS_decode(newOS,newMS,newFS); NFEs=NFEs+1; 
                    fitness = AF{i};
                    if NDS(F1,fitness) == 1 
                        AP{i}=newOS;
                        AM{i}=newMS;
                        AN{i}=newFS;
                        AF{i}=F1;
                     
                    elseif NDS(F1,fitness) == 0 
                        AP=[AP;{newOS}];
                        AM=[AM;{newMS}];
                        AN=[AN;{newFS}];
                        AF=[AF;{F1}];
                    end
                            
                end
            end

            
            L=size(AF,1);
            obj=zeros(L,obj_num);
            for l=1:L
                obj(l,:) = AF{l};
            end
            [PF,~]=pareto1(obj);
            AP=AP(PF,:);AM=AM(PF,:);AN=AN(PF,:);AF=AF(PF,:);
    
            L=length(PF);
            newobj=[];
            for i=1:L
                newobj(i,:)=AF{i};   
            end
            newobj=unique(newobj,'rows');
            
            %动态散点图
%             h.XData = newobj(:,3); h.YData = newobj(:,1); h.ZData = newobj(:,2);
%             pause(0.1);

        end

    
    total_time = toc;
    disp(['总运行时间：', num2str(total_time),'秒']);


    path = [folderName '/num' num2str(round) '.txt'];
    fout=fopen(path,'w');
    fprintf(fout,'%5.2f %6.3f %6.3f\r\n',newobj');
    fclose(fout);

    path_ = [folderName_ '/num' num2str(round) '.txt'];
    fout=fopen(path_,'w');
    fprintf(fout,'%f \r\n',total_time);
    fclose(fout);

    end

end