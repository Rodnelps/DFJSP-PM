function [OS_code,MS_code,FS_code] = PM_encode(OS_code,MS_code,FS_code)
%PM_encode 完善三层编码-在OS编码中加入PM编码0
%   某工序后面出现0意味着需要进行PM
%   PM编码思想如下：
%   将所有工厂中的机器放在一起比较
%   先选机器-负载越高的机器被分配PM的概率越高，但不能超过设定的阈值，以保证各台机器PM数量的相对均衡分配
%   再选工件-随机选择，后续在解码中可能会再进行调整

    global total_operNum  mch_num  factory_num  operNum 

    PM_num = randi([0,total_operNum]); %随机生成PM总数量
    %根据各台机器的负载，均衡地分配PM数量
    if PM_num ~= 0   %PM数量为0意味着没有小修，OS编码中也不包含PM决策编码
        PM_count = zeros(factory_num,mch_num); %统计每家工厂每台机器上已经分配的PM数量
        [mchLoads,possibility] = cal_mchLoad(OS_code,MS_code,FS_code);
        PM_num_threshold = zeros(factory_num,mch_num);
        for f=1:factory_num
            for m=1:mch_num
                PM_num_threshold(f,m) = ceil(PM_num * possibility((f-1)*mch_num+m));
            end
        end

        for n=1:PM_num   %为每一个PM分配具体位置（工厂-机器-工序）
            while 1
                randValue = rand();
                for p=1:length(possibility)
                    if randValue <= possibility(p)
                        corr_f = ceil(p/mch_num);
                        corr_m = mod(p,mch_num);
                        if corr_m == 0; corr_m = mch_num; end
                        if PM_count(corr_f,corr_m) > PM_num_threshold(corr_f,corr_m)
                            %不考虑PM数量饱和的机器，更新mchLoads
                            mchLoads(corr_f,corr_m) = 0;
                            [mchLoads,possibility] = cal_mchLoad(OS_code,MS_code,FS_code,mchLoads);
                            break
                        end
                        %在当前工厂机器上随机选择一个工序插入PM
                        randIndex = randperm(length(OS_code));
                        for rI=1:length(OS_code)
                            curr_job = OS_code(randIndex(rI));
                            if curr_job == 0
                                continue
                            end
                            if randIndex(rI) < length(OS_code) && OS_code(randIndex(rI)+1) == 0
                                continue
                            end
                            curr_oper = oper_identifier(OS_code,randIndex(rI));
                            curr_mch = MS_code(sum(operNum(1:curr_job-1))+curr_oper);
                            curr_factory = FS_code(curr_job);
                            if curr_factory == corr_f && curr_mch == corr_m
                                OS_code = [OS_code(1:randIndex(rI)),0,OS_code(randIndex(rI)+1:end)]; %更新OS编码
                                break
                            end    
                        end   
                        break
                    end
                end
                
                if PM_count(corr_f,corr_m) <= PM_num_threshold(corr_f,corr_m)
                    PM_count(corr_f,corr_m) = PM_count(corr_f,corr_m) + 1;
                    break
                end
            end
        end
    end
   
end
