function [newOS_code,newMS_code,newFS_code]=localSearch_5(OS_code,MS_code,FS_code)
%���ѡ������룬�����깤ʱ����̵Ļ���

     global operNum  avi_mchList  mch_time
    
    newOS_code = OS_code; newMS_code = MS_code; newFS_code = FS_code;
    binary_array = randi([0 1], 1, length(OS_code));
    for i=1:length(OS_code)
        if OS_code(i)~=0 && binary_array(i)==1
            %������������Ӧ�Ļ�������
            curr_job = OS_code(i);
            curr_oper = oper_identifier(OS_code,i);
            curr_mch = MS_code(sum(operNum(1:curr_job-1))+curr_oper);
            if length(avi_mchList{curr_job,curr_oper}) > 1
                tempMchList = avi_mchList{curr_job,curr_oper};
                cMch_index = tempMchList==curr_mch;
                tempMchList(cMch_index) = [];
                PTs = [];
                for m = 1:length(tempMchList)
                    PTs(end+1) = mch_time{curr_job, curr_oper, tempMchList(m)};
                end
                [~,min_index] = min(PTs);
                rand_mch = tempMchList(min_index);
                newMS_code(sum(operNum(1:curr_job-1))+curr_oper) = rand_mch;
            end
        end
    end

end