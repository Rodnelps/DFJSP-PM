function [newOS_1,newMS_1,newFS_1,newOS_2,newMS_2,newFS_2] = crossover(OS_1,MS_1,FS_1,OS_2,MS_2,FS_2)
%crossover OS层采用POX交叉，MS和FS层采用UX交叉
%   由于PM编码数量不固定，OS层整合编码序列会不等长
%   先不考虑维护编码，只针对纯OS编码进行POX交叉，再根据原OS整合编码中0的位置，进行填补

    %% 声明全局变量
    global job_num  total_operNum

    %% 针对OS进行POX交叉
    %暂时删除掉OS编码中的PM决策
    temp_OS_1 = OS_1; non_zero_index = temp_OS_1~=0; temp_OS_1 = temp_OS_1(non_zero_index); 
    temp_OS_2 = OS_2; non_zero_index = temp_OS_2~=0; temp_OS_2 = temp_OS_2(non_zero_index); 

    ref_subset = []; %用来存储工件集的子集，和子集相同的元素保留到下一代
    while isempty(ref_subset)
        ref_subset = find(round(rand(1,job_num))==1);  
    end

    newOS_1 = zeros(1,total_operNum); newOS_2 = zeros(1,total_operNum); %初始化子代1和2的OS编码
    remainList_1 = zeros(1,total_operNum); remainList_2 = zeros(1,total_operNum);
    for i=1:total_operNum
        job_1 = temp_OS_1(i);
        if ismember(job_1,ref_subset)
            newOS_1(i) = job_1;
        else
            remainList_1(i) = job_1;
        end
        
        job_2 = temp_OS_2(i);
        if ismember(job_2,ref_subset)
            newOS_2(i) = job_2;
        else
            remainList_2(i) = job_2;
        end
    end
    
    %子代1
    index1 = find(remainList_2~=0); index2 = find(newOS_1==0);
    for j=1:length(index1)
        newOS_1(index2(j)) = remainList_2(index1(j));
    end
    %子代2
    index3 = find(remainList_1~=0); index4 = find(newOS_2==0);
    for j=1:length(index3)
        newOS_2(index4(j)) = remainList_1(index3(j));
    end
    %将PM决策添加到对应位置
    newOS_1 = add_PM_in_OS(newOS_1,OS_1);
    newOS_2 = add_PM_in_OS(newOS_2,OS_2);
    
    %% 针对MS层进行UX交叉
    newMS_1 = MS_1; newMS_2 = MS_2;
    judgeMS = round(rand(1,total_operNum))==1;
    for i=1:total_operNum
      if judgeMS(i) == 1
         temp = newMS_1(i); newMS_1(i) = newMS_2(i); newMS_2(i) = temp;
       end
    end

    %% 针对FS层进行UX交叉
    newFS_1 = FS_1; newFS_2 = FS_2;
    judgeFS = round(rand(1,job_num))==1;
    for i=1:job_num
      if judgeFS == 1
         temp = newFS_1(i); newFS_1(i) = newFS_2(i); newFS_2(i) = temp;
       end
    end
    
end


