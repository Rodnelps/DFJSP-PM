function operIndex_in_OS = oper_index(operName,OS_code)
%OPER_INDEX 提取某一道工序在OS编码中的索引位置
%   需要给定一道工序[job,oper]，以及OS编码

    job = operName(1); oper = operName(2);
    jobIndices = find(OS_code==job);
    operIndex_in_OS = jobIndices(oper);

end

