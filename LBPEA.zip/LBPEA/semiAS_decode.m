function [obj1,obj2,obj3,actionList,STList,CTList] = semiAS_decode(OS_code,MS_code,FS_code)
%SEMIAS_DECODE 经典的半主动解码策略
%   仅按照编码的顺序依次解码
    
    global factory_num  mch_num  job_num  operNum  mch_time...
        deterRate  CM_threshold  CM_time  unit_M_cost...
        unit_P_ec  unit_I_ec  unit_M_ec
        
    total_PM_time = 0; total_CM_time = 0;
    total_idle_time = 0; %对应总待机能耗
    total_mch_load = 0; %对应总生产能耗
    actionList = cell(factory_num,mch_num);  %存放每家工厂每台机器上的工序/维护活动序列
    STList = cell(factory_num,mch_num);  %开始时间
    CTList = cell(factory_num,mch_num);  %完工时间
    mchAgeList = cell(factory_num,mch_num);  %机器役龄
    real_operCount = zeros(1,job_num); %更新每个工件已经解码完毕的工序数量

    str_list_map = containers.Map; %创建一个Map对象(字典) 存储每一个工序的完工时间

    curr_pos = 1;
    while curr_pos <= length(OS_code) %后续移动位置后需要更新curr_pos
        curr_job = OS_code(curr_pos); 
        curr_oper = real_operCount(curr_job) + 1; real_operCount(curr_job) = curr_oper;
        curr_factory = FS_code(curr_job);
        curr_mch = MS_code(sum(operNum(1:curr_job-1))+curr_oper);
        %提取当前工厂机器上一个工件的完工时间
        if isempty(CTList{curr_factory,curr_mch})
            curr_mch_lastJob_CT = 0;
        else
            curr_mch_lastJob_CT = CTList{curr_factory,curr_mch}{end};
        end
        %提取当前工件上一道工序的完工时间
        if curr_oper == 1
            last_oper_CT = 0;
        else
            last_oper_CT = str_list_map(mat2str([curr_job,curr_oper-1]));
        end
        %初始化开始时间
        tempST = max(curr_mch_lastJob_CT,last_oper_CT);

        %更新工件加工后的相关信息
        actionList{curr_factory,curr_mch} = [actionList{curr_factory,curr_mch} {[curr_job,curr_oper]}];
        STList{curr_factory,curr_mch} = [STList{curr_factory,curr_mch} {tempST}];
        if curr_mch_lastJob_CT ~= 0
            total_idle_time = total_idle_time + (tempST - curr_mch_lastJob_CT);
        end
        if isempty(mchAgeList{curr_factory,curr_mch})
            actualPT = mch_time{curr_job,curr_oper,curr_mch};
            mchAge = actualPT;
        else
            actualPT = mch_time{curr_job,curr_oper,curr_mch} + deterRate * ...
                                        mchAgeList{curr_factory,curr_mch}{end};
            mchAge = mchAgeList{curr_factory,curr_mch}{end} + actualPT;
        end
        total_mch_load = total_mch_load + actualPT;
        mchAgeList{curr_factory,curr_mch} = [mchAgeList{curr_factory,curr_mch} {mchAge}];
        CT = tempST + actualPT;
        CTList{curr_factory,curr_mch} = [CTList{curr_factory,curr_mch} {CT}];
        str_list_map(mat2str([curr_job,curr_oper])) = CT; %存储到字典

        %编码位置不移动则仅标记下一个编码是否为PM决策
        if curr_pos < length(OS_code) && OS_code(curr_pos+1) == 0
            curr_pos = curr_pos + 2; PM_flag = 1;
        else
            curr_pos = curr_pos + 1; PM_flag = 0;
        end

        if PM_flag == 1
            actionList{curr_factory,curr_mch} = [actionList{curr_factory,curr_mch} {'PM'}];
            STList{curr_factory,curr_mch} = [STList{curr_factory,curr_mch} {CT}];
            mchAgeList{curr_factory,curr_mch} = [mchAgeList{curr_factory,curr_mch} {0}];
            if mchAge >= CM_threshold
                %此时PM时间就等同于CM时间
                PM_time = CM_time;
            else
                %PM的时间取决于当前的役龄
                PM_time = (mchAge/CM_threshold) * CM_time;
            end
            CTList{curr_factory,curr_mch} = [CTList{curr_factory,curr_mch} {CT+PM_time}];
            total_PM_time = total_PM_time + PM_time;
        else
            if curr_pos <= length(OS_code) && mchAge >= CM_threshold
                %执行CM
                actionList{curr_factory,curr_mch} = [actionList{curr_factory,curr_mch} {'CM'}];
                STList{curr_factory,curr_mch} = [STList{curr_factory,curr_mch} {CT}];
                mchAgeList{curr_factory,curr_mch} = [mchAgeList{curr_factory,curr_mch} {0}];
                CTList{curr_factory,curr_mch} = [CTList{curr_factory,curr_mch} {CT+CM_time}];
                total_CM_time = total_CM_time + CM_time;
            end
        end
        
    end

    %输出解码后的目标值
    cmax_for_each_mch = [];
    for f=1:factory_num
        for m=1:mch_num
            if ~isempty(CTList{f,m})
                cmax_for_each_mch(end+1) = CTList{f,m}{end};
            end
        end
    end
    
    obj1 = max(cmax_for_each_mch);  %所有工厂的生产周期
    obj2 = unit_P_ec * total_mch_load + unit_M_ec * (total_PM_time + total_CM_time) + ...
            unit_I_ec * total_idle_time;  %所有工厂总能耗
    obj3 = unit_M_cost * (total_PM_time + total_CM_time);  %所有工厂维护总成本

end
