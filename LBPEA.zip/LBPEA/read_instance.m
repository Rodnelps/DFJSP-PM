function [factory_num,job_num,mch_num,operNum,...
    avi_mchNum,avi_mchList,mch_time,total_operNum] = read_instance(readPath)
%READ_INSTANCE 旨在读取指定txt文件中的数据
%   输入一个文件路径，输出关键参数信息

fileID = fopen(readPath,"r");
data = fscanf(fileID,'%d'); %默认列向量
data = data';

factory_num = data(1); job_num = data(2); mch_num = data(3);
pos_index = 4;  %当前位置索引

for job=1:job_num
    operNum(job) = data(pos_index);
    pos_index = pos_index + 1;
    for oper=1:operNum(job)
        avi_mchNum{job,oper} = data(pos_index);
        pos_index = pos_index + 1;
        avi_mchList{job,oper} = [];
        for aviMch=1:avi_mchNum{job,oper}
            avi_mch = data(pos_index);
            avi_mchList{job,oper} = [avi_mchList{job,oper},avi_mch];
            mch_time{job,oper,avi_mch} = data(pos_index+1);
            pos_index = pos_index + 2;
        end
    end
end
total_operNum = sum(operNum); 

end
