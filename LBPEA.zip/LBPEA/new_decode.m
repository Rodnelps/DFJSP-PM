function [OS_code,obj1,obj2,obj3,actionList,STList,CTList] = new_decode(OS_code,MS_code,FS_code)
%NEW_DECODE 一种适配于研究问题的新解码策略
%   按照OS+PM编码的顺序依次进行解码，但解码过程中需要根据如下规则调整解码顺序:
%   1.首先同一家工厂同一台机器上可加工工序的开始时间越早越优先
%   2.若最早开始时间相同，剩余工序数越多的工件越优先
%   3.若剩余工序数量相同，正常加工时间越小越优先（后续工序的恶化效应会小一些）
%   4.若正常加工时间仍相同，则编码序列靠前的工序优先
%   注：当工序需要移动时，需要判断后面是否有编码0，有PM需要一同移动
    
    global factory_num  mch_num  job_num  operNum  mch_time
        

    deterRate = 0.1;  %恶化率，后续可改为每台机器有各自的恶化率
    CM_threshold = 60;
    CM_time = 5;
    unit_M_cost = 10; %单位维护成本
    unit_P_ec = 8; %单位生产能耗
    unit_I_ec = 1; %单位待机能耗
    unit_M_ec = 2; %单位维护能耗

    total_PM_time = 0; total_CM_time = 0;
    total_idle_time = 0; %对应总待机能耗
    total_mch_load = 0; %对应总生产能耗
    actionList = cell(factory_num,mch_num);  %存放每家工厂每台机器上的工序/维护活动序列
    STList = cell(factory_num,mch_num);  %开始时间
    CTList = cell(factory_num,mch_num);  %完工时间
    mchAgeList = cell(factory_num,mch_num);  %机器役龄
    real_operCount = zeros(1,job_num); %更新每个工件已经解码完毕的工序数量

    str_list_map = containers.Map; %创建一个Map对象(字典) 存储每一个工序的完工时间

    curr_pos = 1;
    while curr_pos <= length(OS_code) %后续移动位置后需要更新curr_pos
        temp_operCount = real_operCount;
        curr_job = OS_code(curr_pos); 
        curr_oper = temp_operCount(curr_job) + 1; temp_operCount(curr_job) = curr_oper;
        curr_operName = [curr_job,curr_oper]; %strcat('O',num2str(curr_job),num2str(curr_oper))
        avi_opers = {curr_operName}; %临时存储当前机器可加工的工序
        curr_factory = FS_code(curr_job);
        curr_mch = MS_code(sum(operNum(1:curr_job-1))+curr_oper);
        %提取当前工厂机器上一个工件的完工时间
        if isempty(CTList{curr_factory,curr_mch})
            curr_mch_lastJob_CT = 0;
        else
            curr_mch_lastJob_CT = CTList{curr_factory,curr_mch}{end};
        end
        %提取当前工件上一道工序的完工时间
        if curr_oper == 1
            last_oper_CT = 0;
        else
            last_oper_CT = str_list_map(mat2str([curr_job,curr_oper-1]));
        end
        %初始化开始时间列表，后续比较选出更早的开始时间
        tempST = max(curr_mch_lastJob_CT,last_oper_CT);

        if curr_pos ~= length(OS_code)
            for j=curr_pos+1:length(OS_code)
                temp_job = OS_code(j); 
                if temp_job == 0; continue; end
                temp_oper = temp_operCount(temp_job) + 1; temp_operCount(temp_job) = temp_oper;
                temp_mch = MS_code(sum(operNum(1:temp_job-1))+temp_oper);
                temp_factory = FS_code(temp_job);
                if curr_factory == temp_factory && curr_mch == temp_mch &&...
                   temp_oper - real_operCount(temp_job) == 1
                    avi_opers = [avi_opers {[temp_job,temp_oper]}];
                    if temp_oper == 1
                        last_oper_CT = 0;
                    else
                        last_oper_CT = str_list_map(mat2str([temp_job,temp_oper-1]));
                    end
                    tempST = [tempST max(curr_mch_lastJob_CT,last_oper_CT)];
                end
            end

            %找到tempST中的最小值，如果唯一则对应的工序优先加工，否则进行函数说明2、3、4的判断
            minST = min(tempST); minST_indices = find(tempST==minST);
            if length(minST_indices) == 1
                opt_oper = avi_opers{minST_indices};
            else
                remain_operNum = [];  %存储最早开始时间相同的工件的剩余工序数量
                for i1=1:length(minST_indices)
                    job = avi_opers{minST_indices(i1)}(1);
                    remain_operNum = [remain_operNum operNum(job)-real_operCount(job)];
                end
                maxRON = max(remain_operNum); maxRON_indices = find(remain_operNum==maxRON);
                if length(maxRON_indices) == 1
                    opt_oper = avi_opers{minST_indices(maxRON_indices)};
                else
                    tempPT = [];  %存储剩余工序数量相同工件的正常加工时间
                    for i2=1:length(maxRON_indices)
                        job = avi_opers{minST_indices(maxRON_indices(i2))}(1);
                        oper = avi_opers{minST_indices(maxRON_indices(i2))}(2);
                        tempPT(end+1) = mch_time{job,oper,curr_mch};
                    end
                    minPT = min(tempPT); minPT_indices = find(tempPT==minPT);
                    if length(minPT_indices) == 1
                        opt_oper = avi_opers{minST_indices(maxRON_indices(minPT_indices))};
                    else
                        opt_oper = avi_opers{minST_indices(maxRON_indices(minPT_indices(1)))};
                    end
                end
            end

            %判断opt_oper是否就是curr_operName,相同就不涉及编码位置调整了
            opt_operIndex = oper_index(opt_oper,OS_code);
            if ~isequal(opt_oper,curr_operName)
                %判断需要移动的OS编码并更新OS编码
                if opt_operIndex < length(OS_code) && OS_code(opt_operIndex+1) == 0
                    trans = [opt_oper(1) 0];  %移动工件编码和PM编码
                    OS_code(opt_operIndex:opt_operIndex+1) = [];
                    OS_code = [OS_code(1:curr_pos-1) trans OS_code(curr_pos:end)];
                    curr_pos = curr_pos + 2;
                    PM_flag = 1;
                else
                    trans = opt_oper(1);  %仅移动工件编码
                    OS_code(opt_operIndex) = [];
                    OS_code = [OS_code(1:curr_pos-1) trans OS_code(curr_pos:end)];
                    curr_pos = curr_pos + 1;
                    PM_flag = 0;
                end
            else
                %编码位置不移动则仅标记下一个编码是否为PM决策
                if opt_operIndex < length(OS_code) && OS_code(opt_operIndex+1) == 0
                    curr_pos = curr_pos + 2; PM_flag = 1;
                else
                    curr_pos = curr_pos + 1; PM_flag = 0;
                end
            end

            %将opt_oper加入到机器加工序列，并更新相关指标
            real_operCount(opt_oper(1)) = real_operCount(opt_oper(1)) + 1;
            actionList{curr_factory,curr_mch} = [actionList{curr_factory,curr_mch} ...
                                                    {[opt_oper(1),opt_oper(2)]}];
            STList{curr_factory,curr_mch} = [STList{curr_factory,curr_mch} {minST}];
            total_idle_time = total_idle_time + (minST - curr_mch_lastJob_CT);
            if isempty(mchAgeList{curr_factory,curr_mch})
                actualPT = mch_time{opt_oper(1),opt_oper(2),curr_mch};  %机器的第一个工件
                mchAge = actualPT;
            else
                actualPT = mch_time{opt_oper(1),opt_oper(2),curr_mch} + deterRate * ...
                                            mchAgeList{curr_factory,curr_mch}{end};
                mchAge = mchAgeList{curr_factory,curr_mch}{end} + actualPT;
            end
            total_mch_load = total_mch_load + actualPT;
            mchAgeList{curr_factory,curr_mch} = [mchAgeList{curr_factory,curr_mch} {mchAge}];
            CT = minST + actualPT;
            CTList{curr_factory,curr_mch} = [CTList{curr_factory,curr_mch} {CT}];
            str_list_map(mat2str([opt_oper(1),opt_oper(2)])) = CT; %存储到字典

            if PM_flag == 1
                actionList{curr_factory,curr_mch} = [actionList{curr_factory,curr_mch} {'PM'}];
                STList{curr_factory,curr_mch} = [STList{curr_factory,curr_mch} {CT}];
                mchAgeList{curr_factory,curr_mch} = [mchAgeList{curr_factory,curr_mch} {0}];
                if mchAge >= CM_threshold
                    %此时PM时间就等同于CM时间
                    PM_time = CM_time;
                else
                    %PM的时间取决于当前的役龄
                    PM_time = (mchAge/CM_threshold) * CM_time;
                end
                CTList{curr_factory,curr_mch} = [CTList{curr_factory,curr_mch} {CT+PM_time}];
                total_PM_time = total_PM_time + PM_time;
            else
                if mchAge >= CM_threshold
                    %执行CM
                    actionList{curr_factory,curr_mch} = [actionList{curr_factory,curr_mch} {'CM'}];
                    STList{curr_factory,curr_mch} = [STList{curr_factory,curr_mch} {CT}];
                    mchAgeList{curr_factory,curr_mch} = [mchAgeList{curr_factory,curr_mch} {0}];
                    CTList{curr_factory,curr_mch} = [CTList{curr_factory,curr_mch} {CT+CM_time}];
                    total_CM_time = total_CM_time + CM_time;
                end
            end

        else
            %最后一道工序不需判断直接加工
            real_operCount(curr_job) = real_operCount(curr_job) + 1;
            curr_pos = curr_pos + 1;
            actionList{curr_factory,curr_mch} = [actionList{curr_factory,curr_mch} {[curr_job,curr_oper]}];
            STList{curr_factory,curr_mch} = [STList{curr_factory,curr_mch} {tempST}];
            total_idle_time = total_idle_time + (tempST - curr_mch_lastJob_CT);
            if isempty(mchAgeList{curr_factory,curr_mch})
                actualPT = mch_time{curr_job,curr_oper,curr_mch};  %避免出现极端情况，最后一个也是第一个
                mchAge = actualPT;
            else
                actualPT = mch_time{curr_job,curr_oper,curr_mch} + deterRate * ...
                                            mchAgeList{curr_factory,curr_mch}{end};
                mchAge = mchAgeList{curr_factory,curr_mch}{end} + actualPT;
            end
            total_mch_load = total_mch_load + actualPT;
            mchAgeList{curr_factory,curr_mch} = [mchAgeList{curr_factory,curr_mch} {mchAge}];
            CT = tempST + actualPT;
            CTList{curr_factory,curr_mch} = [CTList{curr_factory,curr_mch} {CT}];
            str_list_map(mat2str([curr_job,curr_oper])) = CT; %存储到字典
        end
    end

    %输出解码后的目标值
    cmax_for_each_mch = [];
    for f=1:factory_num
        for m=1:mch_num
            if ~isempty(CTList{f,m})
                cmax_for_each_mch(end+1) = CTList{f,m}{end};
            end
        end
    end
    
    obj1 = max(cmax_for_each_mch);  %所有工厂的生产周期
    obj2 = unit_P_ec * total_mch_load + unit_M_ec * (total_PM_time + total_CM_time) + ...
            unit_I_ec * total_idle_time;  %所有工厂总能耗
    obj3 = unit_M_cost * (total_PM_time + total_CM_time);  %所有工厂维护总成本

end

