function newOS_code = adjustPM(OS_code,actionList)
%ADJUSTPM 调整维护决策的局部搜索策略
%   遍历每家工厂每台机器，最后一个工序如果存在PM，删除掉
%   如果存在CM，则尝试在CM出现的前几道工序后插入PM
%   否则的话，如果PM的数量大于机器实际负载与CM维护阈值的比值，随机减少一个PM或不改变PM数量仅向右移动PM位置
%           否则的话，随机插入一个PM或不改变PM数量仅向右移动PM位置

    %% 判断每台机器最后一个活动是否为PM
    
    global factory_num  mch_num

    newOS_code = OS_code;
    for f=1:factory_num
        for m=1:mch_num
            if ~isempty(actionList{f,m})
                if isequal(actionList{f,m}{end},'PM') 
                    operName = actionList{f,m}{end-1};
                    operIndex = oper_index(operName,newOS_code);
                    newOS_code(operIndex+1) = [];
                    actionList{f,m}{end} = [];  %后续要统计PM数量 一定要移除
                end
            end
        end
    end

    %% 调整每台机器上的PM数量或位置

    for f=1:factory_num
        for m=1:mch_num
            if ~isempty(actionList{f,m})
                CM_indices = [];
                for i=1:length(actionList{f,m})
                    element = actionList{f,m}{i};
                    if ischar(element) && strcmp(element,'CM')
                        CM_indices = [CM_indices i];
                    end
                end
                %判断每台机器上是否存在CM
                if ~isempty(CM_indices)
                    for j=1:length(CM_indices)
                        if CM_indices(j) > 2 %如果第一个工序后就是CM，无法避免
                            if ~ischar(actionList{f,m}{CM_indices(j)-2})
                                operName = actionList{f,m}{CM_indices(j)-2};
                                operIndex = oper_index(operName,newOS_code);
                                newOS_code = [newOS_code(1:operIndex) 0 newOS_code(operIndex+1:end)];
                            end
                        end
                    end

                else
                    curr_mch_PM_num = 0; curr_mch_oper_num = 0;
                    opers_with_PM = {};  opers_without_PM = {}; %统计工序后是否有PM
                    for i=1:length(actionList{f,m})
                        element = actionList{f,m}{i};
                        if ischar(element) && strcmp(element,'PM')
                            curr_mch_PM_num = curr_mch_PM_num + 1;  %统计PM数量

                        elseif ~ischar(element)
                            curr_mch_oper_num = curr_mch_oper_num +1; %统计工件数量
                            if ~isequal(element,actionList{f,m}{end})
                                next_element = actionList{f,m}{i+1};
                                if ischar(next_element) && strcmp(next_element,'PM')
                                    opers_with_PM = [opers_with_PM {element}];
                                else
                                    opers_without_PM = [opers_without_PM {element}];
                                end
                            else
                                opers_without_PM = [opers_without_PM {element}]; %至少有一道工序（最后一个）
                            end
                        end
                    end
                    
                    %判断当前机器PM数量与工件数量的关系
                    seed = rand;
                    if curr_mch_PM_num > curr_mch_oper_num / 2
                        if seed <= 0.45 %随机减少一个PM
                            rand_operName = opers_with_PM{ceil(rand * length(opers_with_PM))};
                            operIndex = oper_index(rand_operName,newOS_code);
                            newOS_code(operIndex+1) = []; 

                        elseif seed <= 0.9 %插入操作，因为当前PM数量很多，可能会出现几个PM连在一起的情况
                            rand_oper_with_PM = opers_with_PM{ceil(rand * length(opers_with_PM))}; %后面的PM插入到其他位置
                            rand_oper_without_PM = opers_without_PM{ceil(rand * length(opers_without_PM))};
                            %判断插入的是否是机器最后一个工序后面
                            if ~isequal(rand_oper_without_PM,opers_without_PM{end})
                                operIndex1 = oper_index(rand_oper_with_PM,newOS_code);
                                operIndex2 = oper_index(rand_oper_without_PM,newOS_code);
                                %判断两个索引的位置关系
                                if operIndex1 < operIndex2  %先插入再删除
                                    newOS_code = [newOS_code(1:operIndex2) 0 newOS_code(operIndex2+1:end)];
                                    newOS_code(operIndex1+1) = [];
                                else %先删除再插入
                                    newOS_code(operIndex1+1) = [];
                                    newOS_code = [newOS_code(1:operIndex2) 0 newOS_code(operIndex2+1:end)];
                                end
                            end  

                        else %小概率增加一个PM
                            rand_operName = opers_without_PM{ceil(rand * length(opers_without_PM))};
                            if ~isequal(rand_operName,opers_without_PM{end})
                                operIndex = oper_index(rand_operName,newOS_code);
                                newOS_code = [newOS_code(1:operIndex) 0 newOS_code(operIndex+1:end)];
                            end
                        end

                    else 
                        if seed <= 0.3 %随机增加一个PM
                            rand_operName = opers_without_PM{ceil(rand * length(opers_without_PM))};
                            if ~isequal(rand_operName,opers_without_PM{end})
                                operIndex = oper_index(rand_operName,newOS_code);
                                newOS_code = [newOS_code(1:operIndex) 0 newOS_code(operIndex+1:end)];
                            end

                        elseif seed > 0.7 && ~isempty(opers_with_PM) %随机减少一个PM
                            rand_operName = opers_with_PM{ceil(rand * length(opers_with_PM))};
                            operIndex = oper_index(rand_operName,newOS_code);
                            newOS_code(operIndex+1) = []; 
                        end
                    end
                end
            end
        end
    end

end
