function angle_degrees = cal_angle(vector1,vector2)
%cal_angle 计算两个向量的夹角

    % 计算向量的点积
    dot_product = dot(vector1, vector2);
    
    % 计算向量的模
    magnitude_vector1 = norm(vector1);
    magnitude_vector2 = norm(vector2);
    
    % 计算夹角的余弦值
    cosine_angle = dot_product / (magnitude_vector1 * magnitude_vector2);
    
    % 计算夹角的弧度值
    angle_radians = acos(cosine_angle);
    
    % 将弧度值转换为度数
    angle_degrees = rad2deg(angle_radians);
    
%     fprintf('向量1与向量2之间的夹角为 %.2f 度\n', angle_degrees);

end

