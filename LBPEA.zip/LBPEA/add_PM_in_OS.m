function temp_OS_code = add_PM_in_OS(temp_OS_code,OS_code)
%ADD_PM_IN_OS 根据OS_code给temp_OS_code补充PM决策
%   
    
    global job_num

    operCount = zeros(1,job_num);
    for i=1:length(OS_code)
        if OS_code(i) ~= 0
            curr_job = OS_code(i); 
            operCount(curr_job) = operCount(curr_job) + 1;
        else
            corr_job = OS_code(i-1); corr_oper = operCount(corr_job);
            corr_operName = [corr_job, corr_oper];
            PM_index = oper_index(corr_operName,temp_OS_code) + 1;
            temp_OS_code = [temp_OS_code(1:PM_index-1) 0 temp_OS_code(PM_index:end)];
        end
    end

end

