function [state,normalized_fit,sortIndex] = get_state(solution,solution_set)
    
    global obj_num

    refpoint = min(solution_set); 
    nadirpoint = max(solution_set);
    
    normalized_fit = zeros(1,obj_num);
    for j=1:obj_num
        normalized_fit(1,j) = (solution(1,j) - refpoint(j)) / (nadirpoint(j) - refpoint(j));
    end

    [~,sortIndex] = sort(normalized_fit,'descend');

    if sortIndex == [1 2 3]
        state = 1;
    elseif sortIndex == [1 3 2]
        state = 2;
    elseif sortIndex == [2 1 3]
        state = 3;
    elseif sortIndex == [2 3 1]
        state = 4;
    elseif sortIndex == [3 1 2]
        state = 5;
    else
        state = 6;

end