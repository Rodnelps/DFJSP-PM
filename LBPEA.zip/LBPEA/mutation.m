function [newOS,newMS,newFS] = mutation(OS,MS,FS)
%MUTATION 分别对OS、MS和FS三层编码进行变异操作
%   FS编码：
%   (1)随机选择两个不同的工厂，交换位置
%   MS编码：
%   (2)随机选择一个工序对应的机器，换成其它可用的机器
%   OS编码：
%   (3)不考虑PM，随机选择两道工序交换位置，(2)结束后再将PM按照和工序的绑定位置填充
%   (4)在不改变PM数量的前提下，调用PM_encode程序重新分配PM位置

    %% 声明全局变量 
    global job_num  total_operNum  factory_num  operNum  avi_mchList

    %% FS编码层的变异过程
    newFS = FS;
    if factory_num > 1
        diff_fty = unique(FS);
        if length(diff_fty) > 1 %确保工厂编码中包含两个不同的工厂
            rand_fty = diff_fty(randperm(length(diff_fty),2));
            rand_f1_indices = find(FS==rand_fty(1));
            rand_f2_indices = find(FS==rand_fty(2));
            i1 = randperm(length(rand_f1_indices),1); i2 = randperm(length(rand_f2_indices),1);
            p1 = rand_f1_indices(i1); p2 = rand_f2_indices(i2); %确定了FS中的两个位置索引，且对应的工厂不同
            temp = newFS(p1); newFS(p1) = newFS(p2); newFS(p2) = temp; %交换 更新FS层
        end
    end
      
    %% MS编码层的变异过程
    rand_job = randperm(job_num,1);
    rand_oper = randperm(operNum(rand_job),1);
    curr_mch = MS(sum(operNum(1:rand_job-1))+rand_oper);
    avi_mchs = avi_mchList{rand_job,rand_oper};
    newMS = MS;
    if length(avi_mchs) > 1
        while 1
            rand_mch = avi_mchs(ceil(rand*length(avi_mchs)));
            if rand_mch ~= curr_mch
                break
            end
        end
        newMS(sum(operNum(1:rand_job-1))+rand_oper) = rand_mch;
    end

    %% OS编码层的变异过程
    %关于(3)
    temp_OS = OS; non_zero_index = temp_OS~=0; temp_OS = temp_OS(non_zero_index); %暂时删除掉OS编码中的PM决策
    rand_pos = randperm(total_operNum,2); %随机选取两个工序位置
    temp = temp_OS(rand_pos(1)); temp_OS(rand_pos(1)) = temp_OS(rand_pos(2)); temp_OS(rand_pos(2)) = temp; %交换
    %基于(1-3)更新(4)
    [newOS,newMS,newFS] = PM_encode(temp_OS,newMS,newFS);

end

