function [newOS_code,newMS_code,newFS_code] = localSearch_2(OS_code,MS_code,FS_code)
%LOCALSEARCH_2 关键工厂中的任意一个工件，随机分配给其他工厂
%   后续可以尝试改进为完工时间越短的工厂被分配的概率越大

    global factory_num

    newOS_code = OS_code; newMS_code = MS_code; newFS_code = FS_code;

    [cNodes,~,~] = criticalPath(OS_code,MS_code,FS_code);
    rand_cNode = cNodes(ceil(rand * length(cNodes)));   %某道工序在OS编码中的索引
    rand_job = OS_code(rand_cNode);
    cFactory = FS_code(rand_job); %关键路径上的所有节点必定是关键工厂中的
    
    if factory_num > 1
        tempFtyList = 1:factory_num;
        tempFtyList(cFactory) = [];
        rand_fty = tempFtyList(ceil(rand * length(tempFtyList)));
        newFS_code(rand_job) = rand_fty;
    end

end