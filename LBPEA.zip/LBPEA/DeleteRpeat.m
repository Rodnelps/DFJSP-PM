function DeleteRpeat()
global AP AM AN AF;
[m,~]=size(AF);
for i=1:m
    if i>m
        break;
    end
    F=AF{i};
    j=i+1;
    while j<m
        if AF{j}(1)==F(1) && AF{j}(2)==F(2) && AF{j}(3)==F(3)
            AP(j)=[];  %彻底删除了cell的某一行，而不是等于空数组
            AM(j)=[];
            AN(j)=[];
            AF(j)=[];
            j=j-1;
            m=m-1;
        end
        j=j+1;
    end
end
end