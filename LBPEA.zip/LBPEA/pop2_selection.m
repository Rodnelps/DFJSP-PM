function TopPSRank = pop2_selection(pop,num)
%﻿diversity environmental selection 
    
    global obj_num

    TopPSRank=[];

    %适值的正则化
    pop_len = size(pop,1);
    fit = zeros(pop_len,obj_num);
    for i=1:pop_len
        fit(i,:) = pop{i,4};
    end
    normalized_fit = fit_normalize(fit,fit);
    
    %初始化权重向量
    weights = normalized_fit(randperm(pop_len,num),:);

    %划分区域
    for index=1:num
        region(index).Solution = [];
        region(index).Sort = [];
        for individual=1:pop_len
            min_angle = cal_angle(normalized_fit(individual,:),weights(index,:));
            flag = 1;
            for index_=1:num
                if cal_angle(normalized_fit(individual,:),weights(index_,:)) < min_angle
                    flag = 0;
                    break
                end
            end
            if flag == 1
                region(index).Solution = [region(index).Solution individual];
                region(index).Sort = [region(index).Sort weights(index,:)*normalized_fit(individual,:)'];
            end
        end
    end

    %找到每个区域最好的解，存储到TopPSRank中
    for index=1:num
        if ~isempty(region(index).Solution)
            [~,sortIndex] = sort(region(index).Sort,'ascend');
            TopPSRank(end+1) = region(index).Solution(sortIndex(1));
        end
    end

    while length(TopPSRank) < num
        while 1
            rand_solu = randperm(pop_len,1);
            if ~ismember(rand_solu,TopPSRank)
                TopPSRank(end+1) = rand_solu;
                break
            end
        end

    end

end

