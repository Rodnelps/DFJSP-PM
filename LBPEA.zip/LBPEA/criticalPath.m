function [cNodes,cBlocks,blockNum] = criticalPath(OS_code,MS_code,FS_code)
%CRITICALPATH 确定从开始节点到结束节点的最大完工时间的关键路径
%       按照OS编码顺序，先正向解码，确定每个节点（工序）的最早开始时间和实际加工时间
%       再反向解码，确定每个节点的最晚开始时间
%       最晚开始时间与最早开始时间之差最小（为0）的节点，即为关键路径上的节点
%       输出->关键路径、关键块、关键块的数量

    %% 定义全局变量
    global factory_num  mch_num  job_num  operNum  mch_time...
        deterRate  CM_threshold  CM_time

    %% 正向解码——确定每个工序的最早开始时间和实际加工时间
    operCount = zeros(1,job_num); %更新每个工件已经解码完毕的工序数量
    %初始化工序的最早开始、实际加工、最早完工以及最晚开始和最晚完工时间，以及工序后执行维护的时间（没有记为0）
    eStart = {}; process = {}; eFinish = {};
    lStart = {}; lFinish = {}; maintenance = {};
    %初始化每家工厂每台机器的相关信息
    for f=1:factory_num
        for m=1:mch_num
            Machine{f,m}.Oper = []; %存储每台机器上已加工工序
            Machine{f,m}.CT = []; %存储每台机器上工序的完工时间
            Machine{f,m}.Age = []; %存储工序加工后的机器役龄
        end
    end

    i = 1;
    while i <= length(OS_code)  %循环中要调整i值
        job = OS_code(i);
        oper = operCount(job) + 1; operCount(job) = oper;
        fty = FS_code(job);
        mch = MS_code(sum(operNum(1:job-1))+oper);
        PT = mch_time{job,oper,mch}; %正常加工时间

        %提取当前工厂机器上一个工件的完工时间
        if isempty(Machine{fty,mch}.Oper)
            curr_mch_lastJob_CT = 0;
        else
            curr_mch_lastJob_CT = Machine{fty,mch}.CT(end);
        end
        %提取当前工件上一道工序的完工时间
        if oper == 1
            last_oper_CT = 0;
        else
            last_oper_CT = eFinish{job,oper-1};
        end
        %初始化开始时间
        ST = max(curr_mch_lastJob_CT,last_oper_CT);
        eStart{job,oper} = ST;
        %更新工件加工后的相关信息
        Machine{fty,mch}.Oper = [Machine{fty,mch}.Oper, i];
        if isempty(Machine{fty,mch}.Age)
            actualPT = mch_time{job,oper,mch}; 
            mchAge = actualPT;
        else
            actualPT = mch_time{job,oper,mch} + deterRate * Machine{fty,mch}.Age(end);
            mchAge = Machine{fty,mch}.Age(end) + actualPT;
        end
        process{job,oper} = actualPT;
        Machine{fty,mch}.Age = [Machine{fty,mch}.Age, mchAge];
        CT = ST + actualPT;
        Machine{fty,mch}.CT = [Machine{fty,mch}.CT, CT];
        eFinish{job,oper} = CT;
        maintenance{job,oper} = 0; %初始化工序后续的维护时间，如果执行了某种维护，后续更新
        %判断是否进行维护
        if i < length(OS_code) && OS_code(i+1) == 0
            i = i + 2; PM_flag = 1;
        else
            i = i + 1; PM_flag = 0;
        end

        if PM_flag == 1
            if mchAge >= CM_threshold
                PM_time = CM_time; %此时PM时间就等同于CM时间
            else
                PM_time = (mchAge/CM_threshold) * CM_time; %PM的时间取决于当前的役龄
            end
            maintenance{job,oper} = PM_time;
            Machine{fty,mch}.Age = [Machine{fty,mch}.Age, 0];
            Machine{fty,mch}.CT = [Machine{fty,mch}.CT, CT+PM_time];
        else
            if i <= length(OS_code) && mchAge >= CM_threshold
                Machine{fty,mch}.Age = [Machine{fty,mch}.Age, 0];
                Machine{fty,mch}.CT = [Machine{fty,mch}.CT, CT+CM_time];
                maintenance{job,oper} = CM_time;
            end
        end
    end

    %输出解码后的目标值
    cmax_for_each_mch = [];
    for f=1:factory_num
        for m=1:mch_num
            if ~isempty(Machine{f,m}.CT)
                cmax_for_each_mch(end+1) = Machine{f,m}.CT(end);
            end
        end
    end
    CMAX = max(cmax_for_each_mch);  %所有工厂的生产周期

    %% 反向解码——确定每个工序的最晚开始时间

    operCount = operNum;
    %初始化每家工厂每台机器的相关信息
    for f=1:factory_num
        for m=1:mch_num
            Machine{f,m}.ST = []; %存储每台机器上工序的开始时间
        end
    end

    j = length(OS_code);
    while j >= 1  %循环中要调整j值
        if OS_code(j) == 0   %如果编码是0，说明是PM，跳过
            j = j - 1;
        else
            job = OS_code(j);
            oper = operCount(job); operCount(job) = oper - 1;
            fty = FS_code(job);
            mch = MS_code(sum(operNum(1:job-1))+oper);
    
            %提取当前工厂机器上一个工件的开始时间
            if isempty(Machine{fty,mch}.ST)
                curr_mch_lastJob_ST = CMAX - maintenance{job,oper};
            else
                curr_mch_lastJob_ST = Machine{fty,mch}.ST(end) - maintenance{job,oper};
            end
            %提取当前工件上一道工序的开始时间
            if oper == operNum(job)
                last_oper_ST = CMAX;
            else
                last_oper_ST = lStart{job,oper+1};
            end
            %最晚完工时间
            lFinish{job,oper} = min(curr_mch_lastJob_ST,last_oper_ST);
            %最晚开始时间
            lStart{job,oper} = lFinish{job,oper} - process{job,oper};
            Machine{fty,mch}.ST = [Machine{fty,mch}.ST, lStart{job,oper}];
            %更新j
            j = j - 1;
        end
    end

    %% 识别关键路径
    operCount = zeros(1,job_num); %更新每个工件已经解码完毕的工序数量
    cNodes = []; %关键路径上每一个工序在OS中的索引位置
    cMchs = []; %和cNodes中每一个工序相对应的机器
    cOpers = {}; %存储具体的工序名称
    for i=1:length(OS_code)
        if OS_code(i) == 0
            continue
        else
            job = OS_code(i);
            oper = operCount(job) + 1; operCount(job) = oper;
            mch = MS_code(sum(operNum(1:job-1))+oper);
            if ismembertol(lStart{job,oper},eStart{job,oper},1e-3) || ...
               ismembertol(eStart{job,oper},lStart{job,oper},1e-3)  %通过容忍度设置抵消计算误差
                cNodes = [cNodes i];
                cOpers = [cOpers {[job,oper]}];
                cMchs = [cMchs mch];
            end
        end
    end

    %关键块
    blockNum = 1; cBlocks(blockNum).Block = {};
    cBlocks(blockNum).Block = [cBlocks(blockNum).Block cOpers(1)];
    curr_mch = cMchs(1);
    for k=2:length(cNodes)
        if cMchs(k) == curr_mch
            cBlocks(blockNum).Block = [cBlocks(blockNum).Block cOpers(k)];
        else
            blockNum = blockNum + 1;
            cBlocks(blockNum).Block = {};
            cBlocks(blockNum).Block = [cBlocks(blockNum).Block cOpers(k)];
        end
        curr_mch = cMchs(k);
    end

end

