function operIndex = oper_identifier(OS,posIndex)
%oper_identifier 识别工件的工序数
%   需要给定OS编码并给出当前索引位置

operIndex = 0;
for i=1:posIndex
    if OS(i) == OS(posIndex)
        operIndex = operIndex + 1;
    end
end

end