function [OS_code,obj1,obj2,obj3,actionList,STList,CTList] = fullAS_decode(OS_code,MS_code,FS_code)
%FULLAS_DECODE 适用于带有恶化和维护的DFJSP的全主动解码策略
%   基于AS的结果反向插空，先不考虑恶化和维护，完成全主动解码后，
%   补充维护编码，调用半主动解码程序对修正后的编码进行二次解码

    global operNum  factory_num  mch_num  mch_time
    
    temp_OS_code = OS_code;
    non_zero_index = temp_OS_code~=0;
    temp_OS_code = temp_OS_code(non_zero_index); %暂时删除掉OS编码中的PM决策
    operCount = operNum; %更新反向解码的工序数量
    %初始化工序的开始和完工时间
    start = {}; finish = {};
    %初始化每家工厂每台机器的相关信息
    for f=1:factory_num
        for m=1:mch_num
            Machine{f,m}.Oper = []; %存储每台机器上已加工工序
            Machine{f,m}.IT = []; %存储每台机器工序开始加工前的空闲时间
            Machine{f,m}.CT = []; %存储每台机器上工序的完工时间
        end
    end

    %反向解码过程
    for i=length(temp_OS_code):-1:1
        job = temp_OS_code(i);
        oper = operCount(job); operCount(job) = oper - 1;
        fty = FS_code(job);
        mch = MS_code(sum(operNum(1:job-1))+oper);
        PT = mch_time{job,oper,mch}; %正常加工时间
        %判断当前机器上是否有已加工的工序
        if isempty(Machine{fty,mch}.Oper)  
            if oper == operNum(job)
                start{job,oper} = 0;
            else
                start{job,oper} = finish{job,oper+1};
            end
            finish{job,oper} = start{job,oper} + PT;
            Machine{fty,mch}.Oper = [Machine{fty,mch}.Oper, i];
            Machine{fty,mch}.IT = [Machine{fty,mch}.IT, start{job,oper}];
            Machine{fty,mch}.CT = [Machine{fty,mch}.CT, finish{job,oper}];
        else
            insert_flag = 0;
            for j=1:length(Machine{fty,mch}.Oper)
                if Machine{fty,mch}.IT(j) >= PT
                    if oper == operNum(job)  %最后一道工序只需能插到某个空就可以
                        insert_flag = j;
                        break
                    else 
                        if j == 1
                            lastCT = 0;
                        else
                            lastCT = Machine{fty,mch}.CT(j-1);
                        end
                        
                        diff = Machine{fty,mch}.IT(j) - PT;
                        if diff > finish{job,oper+1} - lastCT
                            insert_flag = j;
                            break
                        end
                    end
                end
            end
            %判断是否能插空
            if insert_flag == 0  %没有可用的空，只能加入到机器队列的末尾
                %判断是否为最后一道工序，以更新最早的开始时间以及空闲时间
                if oper == operNum(job)
                    start{job,oper} = Machine{fty,mch}.CT(end);
                    finish{job,oper} = start{job,oper} + PT;
                    Machine{fty,mch}.Oper = [Machine{fty,mch}.Oper, i];
                    Machine{fty,mch}.IT = [Machine{fty,mch}.IT, 0];
                    Machine{fty,mch}.CT = [Machine{fty,mch}.CT, finish{job,oper}];
                else
                    start{job,oper} = max(Machine{fty,mch}.CT(end), finish{job,oper+1});
                    finish{job,oper} = start{job,oper} + PT;
                    Machine{fty,mch}.Oper = [Machine{fty,mch}.Oper, i];
                    idleTime = start{job,oper} - Machine{fty,mch}.CT(end);
                    Machine{fty,mch}.IT = [Machine{fty,mch}.IT, idleTime];
                    Machine{fty,mch}.CT = [Machine{fty,mch}.CT, finish{job,oper}];
                end

            else %将job插入到对应空闲中，并更新相关数组
                insert_pos = Machine{fty,mch}.Oper(insert_flag) + 1;
                temp_OS_code = [temp_OS_code(1:insert_pos-1) job temp_OS_code(insert_pos:end)];
                del_pos = oper_index([job,oper],temp_OS_code);
                temp_OS_code(del_pos) = [];
                %更新每台机器上已加工工序的索引
                for f=1:factory_num
                    for m=1:mch_num
                        for o=1:length(Machine{f,m}.Oper)
                            if Machine{f,m}.Oper(o) <= insert_pos && Machine{f,m}.Oper(o) > i
                                Machine{f,m}.Oper(o) = Machine{f,m}.Oper(o) - 1;
                            end
                        end
                    end
                end
                %将job插入到insert_flag
                Machine{fty,mch}.Oper = [Machine{fty,mch}.Oper(1:insert_flag-1) insert_pos Machine{fty,mch}.Oper(insert_flag:end)];
                if insert_flag == 1 %插入的空是第一个加工位置
                    if oper == operNum(job)
                        start{job,oper} = 0;
                    else
                        start{job,oper} = finish{job,oper+1};
                    end
                else
                    if oper == operNum(job)
                        start{job,oper} = Machine{fty,mch}.CT(insert_flag-1);
                    else
                        start{job,oper} = max(Machine{fty,mch}.CT(insert_flag-1), finish{job,oper+1});
                    end
                end
                finish{job,oper} = start{job,oper} + PT;
                Machine{fty,mch}.CT = [Machine{fty,mch}.CT(1:insert_flag-1) finish{job,oper} Machine{fty,mch}.CT(insert_flag:end)];
                %更新Machine{fty,mch}.IT
                for j=1:length(Machine{fty,mch}.Oper)
                    index_in_OS = Machine{fty,mch}.Oper(j);
                    curr_job = temp_OS_code(index_in_OS);
                    curr_oper = oper_identifier(temp_OS_code,index_in_OS);
                    if j == 1
                        Machine{fty,mch}.IT(j) = start{curr_job,curr_oper};
                    else
                        Machine{fty,mch}.IT(j) = start{curr_job,curr_oper} - Machine{fty,mch}.CT(j-1);
                    end
                end
            end
        end
 
    end

    %给更新后的temp_OS_code补充PM决策
    temp_OS_code = add_PM_in_OS(temp_OS_code,OS_code);

    %调用半主动解码程序输出结果
    OS_code = temp_OS_code;
    [obj1,obj2,obj3,actionList,STList,CTList] = semiAS_decode(OS_code,MS_code,FS_code);
end

