function [OS_code,MS_code,FS_code] = encode()
%encode 构建三层编码 (OS编码中尚未整合PM编码)
%   每调用一次该函数相当于生成一个新个体

    global job_num  operNum  avi_mchList  avi_mchNum  factory_num

    %随机生成OS编码
    OS_code = [];
    for job=1:job_num
        for oper=1:operNum(job)
            OS_code = [OS_code job];
        end
    end
   
    OS_code = OS_code(randperm(length(OS_code)));
    
    %随机生成MS编码 按照工件分块
    MS_code = [];
    for job=1:job_num
        for oper=1:operNum(job)
            rand_mch = avi_mchList{job,oper}(randi(avi_mchNum{job,oper}));
            MS_code = [MS_code rand_mch];
        end
    end

    %随机生成FS编码
    FS_code = [];
    for job=1:job_num
        factory = mod(job,factory_num);
        FS_code = [FS_code factory+1];
    end
    
    FS_code = FS_code(randperm(length(FS_code)));
    
end

    