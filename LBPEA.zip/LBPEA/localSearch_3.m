function [newOS_code,newMS_code,newFS_code] = localSearch_3(OS_code,MS_code,FS_code)
%LOCALSEARCH_3 关键路径上的任意一个工序，随机分配给其他机器
%   后续可以尝试改进为完工时间越短的机器被分配的概率越大

    global operNum  avi_mchList

    newOS_code = OS_code; newMS_code = MS_code; newFS_code = FS_code;

    [cNodes,~,~] = criticalPath(OS_code,MS_code,FS_code);
    rand_cNode = cNodes(ceil(rand * length(cNodes)));   %某道工序在OS编码中的索引
    curr_job = OS_code(rand_cNode);
    curr_oper = oper_identifier(OS_code,rand_cNode);
    curr_mch = MS_code(sum(operNum(1:curr_job-1))+curr_oper);
    
    if length(avi_mchList{curr_job,curr_oper}) > 1
        tempMchList = avi_mchList{curr_job,curr_oper};
        cMch_index = tempMchList==curr_mch;
        tempMchList(cMch_index) = [];
        rand_mch = tempMchList(ceil(rand * length(tempMchList)));
        newMS_code(sum(operNum(1:curr_job-1))+curr_oper) = rand_mch;
    end

end

