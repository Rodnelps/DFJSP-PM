function [newOS_code,newMS_code,newFS_code] = localSearch_1(OS_code,MS_code,FS_code)
%LOCALSEARCH_1 对关键路径进行N6邻域结构调整


    [~,cBlocks,blockNum] = criticalPath(OS_code,MS_code,FS_code);

    newMS_code = MS_code; newFS_code = FS_code;
    newOS_code = OS_code;
    non_zero_index = newOS_code~=0;
    newOS_code = newOS_code(non_zero_index); %暂时删除掉OS编码中的PM决策

    for b=1:blockNum
        bLen = length(cBlocks(b).Block);
        if bLen > 1   %确保关键块内的工序数量大于1
            %Head Block
            if b == 1
                rand_pos = randperm(bLen-1,1); end_pos = bLen;
                rand_oper = cBlocks(b).Block{rand_pos};
                end_oper = cBlocks(b).Block{end_pos};
                rand_index_in_OS = oper_index(rand_oper,newOS_code);
                end_index_in_OS = oper_index(end_oper,newOS_code);

                newOS_code = [newOS_code(1:end_index_in_OS) newOS_code(rand_index_in_OS) newOS_code(end_index_in_OS+1:end)];   
                newOS_code(rand_index_in_OS) = []; 
            end
            %Tail Block
            if b == blockNum
                start_pos = 1; rand_pos = randperm(bLen-1,1) + 1;
                start_oper = cBlocks(b).Block{start_pos};
                rand_oper = cBlocks(b).Block{rand_pos};
                start_index_in_OS = oper_index(start_oper,newOS_code);
                rand_index_in_OS = oper_index(rand_oper,newOS_code);

                temp = newOS_code(rand_index_in_OS); 
                newOS_code(rand_index_in_OS) = [];
                newOS_code = [newOS_code(1:start_index_in_OS-1) temp newOS_code(start_index_in_OS:end)];
            end
            %Middle Block
            if b > 1 && b < blockNum && bLen > 3
                start_pos = 1; 
                rand_pos = randperm(bLen-2,2) + 1;
                start_oper = cBlocks(b).Block{start_pos};
                rand_oper = cBlocks(b).Block{rand_pos(1)};  %插入到第一个工序之前
                start_index_in_OS = oper_index(start_oper,newOS_code);
                rand_index_in_OS = oper_index(rand_oper,newOS_code);

                temp = newOS_code(rand_index_in_OS); 
                newOS_code(rand_index_in_OS) = [];
                newOS_code = [newOS_code(1:start_index_in_OS-1) temp newOS_code(start_index_in_OS:end)];
               
                rand_oper = cBlocks(b).Block{rand_pos(2)};
                rand_index_in_OS = oper_index(rand_oper,newOS_code);
                end_pos = bLen; end_oper = cBlocks(b).Block{end_pos};
                end_index_in_OS = oper_index(end_oper,newOS_code);

                newOS_code = [newOS_code(1:end_index_in_OS) newOS_code(rand_index_in_OS) newOS_code(end_index_in_OS+1:end)];
                newOS_code(rand_index_in_OS) = [];
            end
        end
    end

    newOS_code = add_PM_in_OS(newOS_code,OS_code); %给更新后的temp_OS_code补充PM决策
    newMS_code = MS_code;
    newFS_code = FS_code;

end

