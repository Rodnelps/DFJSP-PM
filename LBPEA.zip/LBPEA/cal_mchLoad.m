function [mchLoads,possibility] = cal_mchLoad(OS,MS,FS,mchLoads)
%CAL_MCHLOAD 计算机器负载
%   给定不考虑维护的三层编码，输出每台机器的总正常加工时间占比的累计概率

    global job_num  operNum  factory_num  mch_num  mch_time

    if ~exist('mchLoads','var')
        operCount = zeros(1,job_num);
        mchLoads = zeros(factory_num,mch_num);
        for i=1:length(OS)
            curr_job = OS(i);
            curr_oper = operCount(curr_job) + 1;
            operCount(curr_job) = curr_oper;
            curr_factory = FS(curr_job);
            curr_mch = MS(sum(operNum(1:curr_job-1)) + curr_oper);
            mchLoads(curr_factory,curr_mch) = mchLoads(curr_factory,curr_mch) +...
                mch_time{curr_job,curr_oper,curr_mch};
        end
    end
    
    load_proportion = zeros(factory_num,mch_num);possibility = [];
    for f=1:factory_num
        for m=1:mch_num
            load_proportion(f,m) = mchLoads(f,m) / sum(mchLoads(:));
        end
    end
    
    load_proportion = reshape(load_proportion,1,[]); %转换为一行
    for fm=1:length(load_proportion)
        possibility = [possibility sum(load_proportion(1:fm))];  %按照"F1M1,F1M2,F2M1,F2M2"的顺序
    end
end
