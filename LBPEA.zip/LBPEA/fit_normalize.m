function normalized_fit = fit_normalize(fit,ref)
%normalize 对目标函数进行正则化处理
%   ref的导入很关键，对于多组数据的正则化，参考点要依赖于所有数据的最大和最小

    obj_num = 3;

    refpoint = min(ref); 
    nadirpoint = max(ref);
    
    row = size(fit,1);
    normalized_fit = zeros(row,obj_num);
    for i=1:row
        for j=1:obj_num
            normalized_fit(i,j) = (fit(i,j) - refpoint(j)) / (nadirpoint(j) - refpoint(j));
        end
    end

end

